#include <SFML/Graphics.hpp>
#include <algorithm>
#include <sstream>
#include <unistd.h>
#include <ctime>
#include <string>
#include <iostream>
#include <queue>
#include "physicsEngine.h"
#define RES_FONT    "resources/ubuntu.ttf"

using namespace sf;

Vector2f player_move(Collider &p){
    Vector2i start(-1,-1);
    Vector2i finish(-1,-1);
    if(p.tempStatic){
        
        while(Mouse::isButtonPressed(Mouse::Left)){
            if(start.x==-1){
                start=Mouse::getPosition();
            }
            finish=Mouse::getPosition();
        }
    }
    Vector2f movement(finish.x-start.x, finish.y-start.y);
    if(start.x>0){p.tempStatic=false;}
    return movement;
}

void resetPlayer(Collider &p1){
    p1.shape=0;
    p1.x=90.0;
    p1.y=100.0;
    p1.radius=20.0;
    p1.radius2=0.0; 
    p1.isStatic=false;
    p1.tempStatic=false;
    p1.velocity_y = 1.0;
    p1.velocity_x = 0.5;
    p1.acceleration_y = gravity;
    p1.acceleration_x = 80.0;
    p1.mass = 5.0;
    p1.material = "rubber";
}


int main(){
    Clock clock;

    Color gray(100,100,100);

    Collider p1;
    p1.shape=0;
    p1.x=90.0;
    p1.y=100.0;
    p1.radius=20.0;
    p1.radius2=0.0; 
    p1.isStatic=false;
    p1.tempStatic=false;
    p1.velocity_y = 1.0;
    p1.velocity_x = 0.5;
    p1.acceleration_y = gravity;
    p1.acceleration_x = 80.0;
    p1.mass = 5.0;
    p1.material = "rubber";

    Collider p2;
    p2.shape=0;
    p2.x=600.0;
    p2.y=100.0;
    p2.radius=20.0;
    p2.radius2=0.0; 
    p2.isStatic=false;
    p2.tempStatic=false;
    p2.velocity_y = 1.0;
    p2.velocity_x = 0.5;
    p2.acceleration_y = gravity;
    p2.acceleration_x = -70.0;
    p2.mass = 5.0;
    p2.material = "rubber";

    Collider lwall;
    lwall.shape=1;
    lwall.x=0.0;
    lwall.y=0.0;
    lwall.radius=30.0;
    lwall.radius2=800.0;
    lwall.isStatic=true;
    lwall.mass = 50.0;
    lwall.material = "hard";

    Collider bwall;
    bwall.shape=1;
    bwall.x=0.0;
    bwall.y=770.0;
    bwall.radius=800.0;
    bwall.radius2=30.0;
    bwall.isStatic=true;
    bwall.mass = 50.0;
    bwall.material = "hard";

    Collider rwall;
    rwall.shape=1;
    rwall.x=770.0;
    rwall.y=0.0;
    rwall.radius=30.0;
    rwall.radius2=800.0;
    rwall.isStatic=true;
    rwall.mass = 50.0;
    rwall.material = "hard";

    Collider uwall;
    uwall.shape=1;
    uwall.x=30.0;
    uwall.y=0.0;
    uwall.radius=740.0;
    uwall.radius2=30.0;
    uwall.isStatic=true;
    uwall.mass = 50.0;
    uwall.material = "hard";

    Collider goal;
    goal.shape=1;
    goal.x=350.0;
    goal.y=350.0;
    goal.radius=70.0;
    goal.radius2=70.0;
    goal.isStatic=true;
    goal.mass = 50.0;
    goal.material = "hard";

    Collider lgoal;
    lgoal.shape=1;
    lgoal.x=330.0;
    lgoal.y=350.0;
    lgoal.radius=20.0;
    lgoal.radius2=70.0;
    lgoal.isStatic=true;
    lgoal.mass = 50.0;
    lgoal.material = "hard";

    Collider ugoal;
    ugoal.shape=1;
    ugoal.x=330.0;
    ugoal.y=420.0;
    ugoal.radius=110.0;
    ugoal.radius2=20.0;
    ugoal.isStatic=true;
    ugoal.mass = 50.0;
    ugoal.material = "hard";

    Collider rgoal;
    rgoal.shape=1;
    rgoal.x=420.0;
    rgoal.y=350.0;
    rgoal.radius=20.0;
    rgoal.radius2=70.0;
    rgoal.isStatic=true;
    rgoal.mass = 50.0;
    rgoal.material = "hard";

    Collider plat;
    plat.shape=1;
    plat.x=480.0;
    plat.y=320.0;
    plat.radius=80.0;
    plat.radius2=20.0;
    plat.isStatic=true;
    plat.mass = 50.0;
    plat.material = "sticky";

    Collider plat2;
    plat2.shape=1;
    plat2.x=600.0;
    plat2.y=280.0;
    plat2.radius=80.0;
    plat2.radius2=20.0;
    plat2.isStatic=true;
    plat2.mass = 50.0;
    plat2.material = "hard";


    CircleShape player;
    player.setPosition(p1.x, p1.y);
    player.setRadius(p1.radius); 
    player.setFillColor(Color::Green);

    CircleShape ball_1;
    ball_1.setPosition(p2.x, p2.y);
    ball_1.setRadius(p2.radius);
    ball_1.setFillColor(Color::Red);

    RectangleShape ground_1;
    ground_1.setPosition(lwall.x, lwall.y);
    ground_1.setSize(Vector2f(lwall.radius,lwall.radius2)); 
    ground_1.setFillColor(gray);

    RectangleShape ground_2;
    ground_2.setPosition(bwall.x, bwall.y);
    ground_2.setSize(Vector2f(bwall.radius,bwall.radius2)); 
    ground_2.setFillColor(gray);

    RectangleShape ground_3;
    ground_3.setPosition(rwall.x, rwall.y);
    ground_3.setSize(Vector2f(rwall.radius,rwall.radius2)); 
    ground_3.setFillColor(gray);

    RectangleShape ground_4;
    ground_4.setPosition(uwall.x, uwall.y);
    ground_4.setSize(Vector2f(uwall.radius,uwall.radius2)); 
    ground_4.setFillColor(gray);

    RectangleShape goal_1;
    goal_1.setPosition(goal.x, goal.y);
    goal_1.setSize(Vector2f(goal.radius, goal.radius2));
    goal_1.setFillColor(Color::Blue);

    RectangleShape goal_wall1;
    goal_wall1.setPosition(lgoal.x, lgoal.y);
    goal_wall1.setSize(Vector2f(lgoal.radius, lgoal.radius2));
    goal_wall1.setFillColor(gray);

    RectangleShape goal_wall2;
    goal_wall2.setPosition(ugoal.x, ugoal.y);
    goal_wall2.setSize(Vector2f(ugoal.radius, ugoal.radius2));
    goal_wall2.setFillColor(gray);

    RectangleShape goal_wall3;
    goal_wall3.setPosition(rgoal.x, rgoal.y);
    goal_wall3.setSize(Vector2f(rgoal.radius, rgoal.radius2));
    goal_wall3.setFillColor(gray);

    RectangleShape plat_1;
    plat_1.setPosition(plat.x, plat.y);
    plat_1.setSize(Vector2f(plat.radius, plat.radius2));
    plat_1.setFillColor(Color::Magenta);

    RectangleShape plat_2;
    plat_2.setPosition(plat2.x, plat2.y);
    plat_2.setSize(Vector2f(plat2.radius, plat2.radius2));
    plat_2.setFillColor(gray);

    int state = 0;

    int moves = 0;

    Font font;
    if (!font.loadFromFile(RES_FONT)) return EXIT_FAILURE;          // could not load font

    RenderWindow window(VideoMode(800, 800), "Gravity Demo");

    Collider* colliders[] = {&p1, &lwall, &bwall, &rwall, &uwall, &p2, &lgoal, &ugoal, &rgoal, &plat, &plat2};

    while(window.isOpen()){
        Event event;
        while (window.pollEvent(event))
        {
            if (event.type == Event::Closed)
                window.close();
        }
        if(state==0){
            window.clear();
            Text Title("Puzzle", font, 50);
            Text desc("Try to get all the balls into the goal", font, 30);
            Text controls("Click LMB and drag to move when ball is at rest", font, 25);
            Text controls1("You control the green ball", font, 25);
            Text start("Press Enter to start", font, 30);
            controls.setFillColor(sf::Color::Red);
            controls1.setFillColor(sf::Color::Green);
            Title.setPosition(270,100);
            desc.setPosition(140, 200);
            controls.setPosition(100,250);
            controls1.setPosition(200,300);
            start.setPosition(210, 400);
            window.draw(Title);
            window.draw(desc);
            window.draw(controls);
            window.draw(controls1);
            window.draw(start);
            window.display();

            if(sf::Keyboard::isKeyPressed(sf::Keyboard::Enter)){
                state = 1;
                resetPlayer(p1);
                p2.x=600.0;
                p2.y=100.0;
                p2.radius=20.0;
                p2.radius2=0.0; 
                p2.isStatic=false;
                p2.tempStatic=false;
                p2.velocity_y = 1.0;
                p2.velocity_x = 0.5;
                p2.acceleration_y = gravity;
                p2.acceleration_x = -70.0;
                p2.mass = 5.0;
                p2.material = "rubber";
                moves=0;
                clock.restart();
            }
        }

        if(state==1){
            
            if(collision(&p1,&goal) && collision(&p2, &goal)){
                state=2;
            }

            if(Keyboard::isKeyPressed(Keyboard::R)){
                resetPlayer(p1);
                p2.x=600.0;
                p2.y=100.0;
                p2.radius=20.0;
                p2.radius2=0.0; 
                p2.isStatic=false;
                p2.tempStatic=false;
                p2.velocity_y = 1.0;
                p2.velocity_x = 0.5;
                p2.acceleration_y = gravity;
                p2.acceleration_x = -70.0;
                p2.mass = 5.0;
                p2.material = "rubber";
                moves=0;
            }

            if(moves>4 && p1.tempStatic){
                resetPlayer(p1);
                p2.x=600.0;
                p2.y=100.0;
                p2.radius=20.0;
                p2.radius2=0.0; 
                p2.isStatic=false;
                p2.tempStatic=false;
                p2.velocity_y = 1.0;
                p2.velocity_x = 0.5;
                p2.acceleration_y = gravity;
                p2.acceleration_x = -70.0;
                p2.mass = 5.0;
                p2.material = "rubber";
                moves=0;
            }
            do_collisions(colliders, 11);

            float DT=(clock.getElapsedTime().asSeconds())*1.5;
            
            Vector2f movement = player_move(p1);
            //std::cout<<movement.x<<std::endl;
            //std::cout<<movement.y<<std::endl;
            if(abs(movement.x)>1 || abs(movement.y)>1){
                //std::cout<<movement.x<<std::endl;
                moves++;
            }
            //std::cout<<movement.y<<std::endl;
            p1.velocity_x+=movement.x;
            p1.velocity_y+=movement.y;
            velocityUpdate(&p1, DT);
            //std::cout<<p1.acceleration_x<<std::endl;
            //std::cout<<p1.acceleration_y<<std::endl;
            //std::cout<<""<<std::endl;
            velocityUpdate(&p2,DT);

            clock.restart();

            Text moveCounter(std::to_string(moves), font, 40);
            moveCounter.setPosition(40,40);

            player.setPosition(p1.x, p1.y);
            ball_1.setPosition(p2.x, p2.y);
            window.clear();
            window.draw(moveCounter);
            window.draw(player);
            window.draw(ball_1);
            window.draw(goal_1);
            window.draw(goal_wall1);
            window.draw(goal_wall2);
            window.draw(goal_wall3);
            window.draw(ground_1);
            window.draw(ground_2);
            window.draw(ground_3);
            window.draw(ground_4);
            window.draw(plat_1);
            window.draw(plat_2);
            window.draw(player);
            window.draw(ball_1);
            window.display();
        }
        if(state==2){
            window.clear();
            //sf::Text congrats("null", font, 50);
            sf::Text win("YOU WIN!", font, 45);
            sf::Text title("Press T to return to the title screen",font, 30);
            sf::Text pa("Press P to play again!", font, 30);
            win.setPosition(300, 150);
            title.setPosition(150, 250);
            pa.setPosition(250, 300);
            //window.draw(congrats);
            window.draw(win);
            window.draw(title);
            window.draw(pa);
            window.display();

            if(Keyboard::isKeyPressed(Keyboard::T)){
                state = 0;
            }
            if(Keyboard::isKeyPressed(Keyboard::P)){
                state = 1;
                resetPlayer(p1);
                p2.x=600.0;
                p2.y=100.0;
                p2.radius=20.0;
                p2.radius2=0.0; 
                p2.isStatic=false;
                p2.tempStatic=false;
                p2.velocity_y = 1.0;
                p2.velocity_x = 0.5;
                p2.acceleration_y = gravity;
                p2.acceleration_x = -70.0;
                p2.mass = 5.0;
                p2.material = "rubber";
                moves=0;
                clock.restart();
            }
        }

        
    }
    return 0;
}

