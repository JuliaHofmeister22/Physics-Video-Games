#include <SFML/Graphics.hpp>
#include <algorithm>
#include <sstream>
#include <unistd.h>
#include <ctime>
#include <string>
#include <iostream>
#include <queue>
#include "physicsEngine.h"

using namespace sf;

RenderWindow window(VideoMode(800, 800), "Gravity Demo");

int main()
{
    Font arial;
    if (!arial.loadFromFile("resources/arial.ttf")) return EXIT_FAILURE; //fontspace credits

    Text instruct("Click on blue objects to make them disappear!",arial, 20);
    instruct.setPosition(30, 10);
    instruct.setFillColor(Color::Green);

    Text instruct2("Land the ball on the orange platform to win.",arial, 20);
    instruct2.setPosition(30, 30);
    instruct2.setFillColor(Color::Green);

    Text won("You Won!",arial,80);
    won.setPosition(200, 150);
    won.setFillColor(Color::Green);

    Text fail("You Failed",arial,80);
    fail.setPosition(200, 150);
    fail.setFillColor(Color::Red);

    Text restart("Restart",arial,20);
    restart.setPosition(350, 520);
    restart.setFillColor(Color::Black);

    Clock clock;

    Collider ball;
    ball.shape=0;
    ball.x=370.0;
    ball.y=200.0;
    ball.radius=40.0;
    ball.radius2=0.0; 
    ball.isStatic=false;
    ball.tempStatic=false;
    ball.velocity_y = 2.0;
    ball.velocity_x = 1.0;
    ball.acceleration_y = gravity;
    ball.acceleration_x = -10.0;
    ball.mass = 10.0;
    ball.material = "rubber";
    ball.canDisappear = false;

    Collider ground;
    ground.shape=1;
    ground.x=0.0;
    ground.y=740.0;
    ground.radius=800.0;
    ground.radius2=60.0;
    ground.isStatic=true;
    ground.mass = 100.0;
    ground.material = "hard";
    ball.canDisappear = false;

    Collider box;
    box.shape=1;
    box.x=410.0;
    box.y=400.0;
    box.radius=80.0;
    box.radius2=80.0;
    box.isStatic=true;
    box.mass = 40.0;
    box.material = "soft";
    box.canDisappear = true;

    Collider side;
    side.shape=1;
    side.x=300.0;
    side.y=500.0;
    side.radius=20.0;
    side.radius2=80.0;
    side.isStatic=true;
    side.mass = 40.0;
    side.material = "hard";
    side.canDisappear = true;

    Collider goal;
    goal.shape=1;
    goal.x=300.0;
    goal.y=660.0;
    goal.radius=160.0;
    goal.radius2=20.0;
    goal.isStatic=true;
    goal.mass = 40.0;
    goal.material = "soft";
    ball.canDisappear = false;

    //Colors: gray=metal; green=rubber; red=plastic; orange=sticky
    Color gray(100,100,100);
    Color orange(255,165,100);

    CircleShape player;
    player.setPosition(ball.x, ball.y);
    player.setRadius(ball.radius); 
    player.setFillColor(Color::Green);

    RectangleShape ground_1;
    ground_1.setPosition(ground.x, ground.y);
    ground_1.setSize(Vector2f(ground.radius,ground.radius2)); 
    ground_1.setFillColor(gray);

    RectangleShape goal_1;
    goal_1.setPosition(goal.x, goal.y);
    goal_1.setSize(Vector2f(goal.radius,goal.radius2)); 
    goal_1.setFillColor(orange);

    RectangleShape side_1;
    side_1.setPosition(side.x, side.y);
    side_1.setSize(Vector2f(side.radius,side.radius2)); 
    side_1.setFillColor(Color::Blue);

    RectangleShape box_1;
    box_1.setPosition(box.x, box.y);
    box_1.setSize(Vector2f(box.radius,box.radius2)); 
    box_1.setFillColor(Color::Blue);

    RectangleShape start;
    start.setPosition(340, 500);
    start.setSize(Vector2f(100,80)); 
    start.setFillColor(Color::Green);

    //CircleShape circs[] = {player};
    //int circsize = 1;

    RectangleShape rects[] = {ground_1, goal_1, box_1, side_1};
    int rectsize = 4;

    Collider* colliders[] = {&ball, &goal, &ground, &box, &side};
    int size=5;

    int scene = 0;
    int timecount = 0;
    while (window.isOpen())
    {
        Event event;
        while (window.pollEvent(event))
        {
            if (event.type == Event::Closed)
                window.close();
        }
        float DT=clock.getElapsedTime().asSeconds();
        if(scene==0){
            if (collision(&ball, &ground)){
                usleep(500000);
                //wait a few seconds and then go to failed screen
                scene = 1;
            }
            if (collision(&ball, &goal)){
                usleep(500000);
                //wait a few seconds and then go to win screen
                scene = 2;
            }
            do_collisions(colliders, size);
            velocityUpdate(&ball, DT);
            Vector2i mouse_pos = Mouse::getPosition(window);
            if (Mouse::isButtonPressed(Mouse::Left)){
                for (int i=0; i<size; i++){
                    if (mouse_pos.x >= colliders[i]->x && mouse_pos.x <= (colliders[i]->x+colliders[i]->radius)
                        && mouse_pos.y>=colliders[i]->y && mouse_pos.x <= (colliders[i]->y+colliders[i]->radius2) && colliders[i]->canDisappear == true){
                        size-=1;
                        //std::cout<<colliders[i]->y<<std::endl;
                        //std::cout<<mouse_pos.y<<std::endl;
                        Collider* disappear = colliders[i];
                        for (int j=i; j<size; j++){
                            colliders[j]= colliders[j+1];
                        }
                        if (disappear->shape == 1){
                            for (int k=0; k<rectsize; k++){
                                if (rects[k].getPosition().x == disappear->x && rects[k].getPosition().y == disappear->y){
                                    rectsize-=1;
                                    for (int l=k; l<rectsize; l++){
                                        rects[l] = rects[l+1];   
                                    }
                                }
                            }
                        }
                    break;
                    }
                }
            }  
            clock.restart();
            player.setPosition(ball.x, ball.y);
            window.clear();
            for (int i=0; i<rectsize; i++){
                window.draw(rects[i]);
            }
            window.draw(player);
            window.draw(instruct);  
            window.draw(instruct2);  

        }
        if(scene==1){
            Vector2i mouse_pos = Mouse::getPosition(window);
            if (Mouse::isButtonPressed(Mouse::Left)){
                if (mouse_pos.x >= start.getPosition().x && mouse_pos.x <= (start.getPosition().x+start.getSize().x)
                        && mouse_pos.y>=start.getPosition().y && mouse_pos.x <= start.getPosition().y+start.getSize().y){
                    main();
                }
            }
            window.clear();
            window.draw(fail);
            window.draw(start);
            window.draw(restart);  
        }  
        if(scene==2){
            Vector2i mouse_pos = Mouse::getPosition(window);
            if (Mouse::isButtonPressed(Mouse::Left)){
               if (mouse_pos.x >= start.getPosition().x && mouse_pos.x <= (start.getPosition().x+start.getSize().x)
                        && mouse_pos.y>=start.getPosition().y && mouse_pos.x <= start.getPosition().y+start.getSize().y){
                    main();
                }
            }
            window.clear();
            window.draw(won);
            window.draw(start);
            window.draw(restart);   
        }
	    window.display();   
    }

    return 0;
}
           

