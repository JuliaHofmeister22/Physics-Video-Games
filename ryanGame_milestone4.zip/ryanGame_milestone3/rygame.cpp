#include <SFML/Graphics.hpp>
#include <algorithm>
#include <sstream>
#include <unistd.h>
#include <ctime>
#include <string>
#include <iostream>
#include <queue>
#include "physicsEngine.h"
#define RES_FONT    "resources/ubuntu.ttf"

using namespace sf;

struct Dispenser{
    float x;
    float y;
    bool hasFired;
};

Vector2f player_move(Collider &p){
    Vector2i start(-1,-1);
    Vector2i finish(-1,-1);
    if(p.tempStatic){
        
        while(Mouse::isButtonPressed(Mouse::Left)){
            if(start.x==-1){
                start=Mouse::getPosition();
            }
            finish=Mouse::getPosition();
        }
    }
    Vector2f movement(finish.x-start.x, finish.y-start.y);
    if(start.x>0){
        p.tempStatic=false;
        p.acceleration_y=gravity;
    }
    return movement;
}

void resetPlayer(Collider &p1, int state){
    if(state==1){
        p1.x=90.0;
        p1.y=100.0;
        p1.isStatic=false;
        p1.tempStatic=false;
        p1.velocity_y = 1.0;
        p1.velocity_x = 0.5;
        p1.acceleration_y = gravity;
        p1.acceleration_x = 80.0;
    }
    if(state==3){
        p1.x=700;
        p1.y=700;
        p1.velocity_x=0.0;
        p1.velocity_y=0.0;
        p1.acceleration_x=0.0;
        p1.acceleration_y=gravity;
        p1.isStatic=false;
        p1.tempStatic=false;
    }
    if(state==5){
        p1.x=400;
        p1.y=700;
        p1.velocity_x=0.0;
        p1.velocity_y=0.0;
        p1.acceleration_x=0.0;
        p1.acceleration_y=gravity;
        p1.isStatic=false;
        p1.tempStatic=false;
    }   
}


int main(){
    Clock clock;

    Color gray(100,100,100);

    Color brown(150,75,0);

    Color purple(128,0, 128);

    
    Dispenser d1;
    d1.x=770;
    d1.y=50;
    d1.hasFired=false;

    Dispenser d2;
    d2.x=10;
    d2.y=100;
    d2.hasFired=false;

    //initiallizing all of the Collider objects
    Collider arrow;
    arrow.shape=1;
    arrow.x=d1.x+5;
    arrow.y=d1.y+10;
    arrow.radius=10;
    arrow.radius2=5;
    arrow.isStatic=false;
    arrow.tempStatic=false;
    arrow.velocity_x=0.0;
    arrow.velocity_y=0.0;
    arrow.acceleration_x=0.0;
    arrow.acceleration_y=0.0;
    arrow.mass=3.0;
    arrow.material="plastic";

    Collider arrow2;
    arrow2.shape=1;
    arrow2.x=d2.x+5;
    arrow2.y=d2.y+10;
    arrow2.radius=10;
    arrow2.radius2=5;
    arrow2.isStatic=false;
    arrow2.tempStatic=false;
    arrow2.velocity_x=0.0;
    arrow2.velocity_y=0.0;
    arrow2.acceleration_x=0.0;
    arrow2.acceleration_y=0.0;
    arrow2.mass=3.0;
    arrow2.material="plastic";

    Collider button1;
    button1.shape=1;
    button1.x=640;
    button1.y=750;
    button1.radius=30;
    button1.radius2=20;
    button1.isStatic=true;

    Collider button2;
    button2.shape=1;
    button2.x=160;
    button2.y=750;
    button2.radius=30;
    button2.radius2=20;
    button2.isStatic=true;
    

    Collider p1;
    p1.shape=0;
    p1.x=90.0;
    p1.y=100.0;
    p1.radius=20.0;
    p1.radius2=0.0; 
    p1.isStatic=false;
    p1.tempStatic=false;
    p1.velocity_y = 1.0;
    p1.velocity_x = 0.5;
    p1.acceleration_y = gravity;
    p1.acceleration_x = 80.0;
    p1.mass = 5.0;
    p1.material = "rubber";

    Collider p2;
    p2.shape=0;
    p2.x=600.0;
    p2.y=100.0;
    p2.radius=20.0;
    p2.radius2=0.0; 
    p2.isStatic=false;
    p2.tempStatic=false;
    p2.velocity_y = 1.0;
    p2.velocity_x = 0.5;
    p2.acceleration_y = gravity;
    p2.acceleration_x = -70.0;
    p2.mass = 5.0;
    p2.material = "rubber";

    Collider p3;
    p3.shape=0;
    p3.x=680.0;
    p3.y=50.0;
    p3.radius=20.0;
    p3.radius2=0.0; 
    p3.isStatic=false;
    p3.tempStatic=false;
    p3.velocity_y = 0.1;
    p3.velocity_x = 0.1;
    p3.acceleration_y = gravity;
    p3.acceleration_x = 0.0;
    p3.mass = 5.0;
    p3.material = "rubber";

    Collider lwall;
    lwall.shape=1;
    lwall.x=0.0;
    lwall.y=0.0;
    lwall.radius=30.0;
    lwall.radius2=800.0;
    lwall.isStatic=true;
    lwall.mass = 50.0;
    lwall.material = "hard";

    Collider bwall;
    bwall.shape=1;
    bwall.x=0.0;
    bwall.y=770.0;
    bwall.radius=800.0;
    bwall.radius2=30.0;
    bwall.isStatic=true;
    bwall.mass = 50.0;
    bwall.material = "hard";

    Collider rwall;
    rwall.shape=1;
    rwall.x=770.0;
    rwall.y=0.0;
    rwall.radius=30.0;
    rwall.radius2=800.0;
    rwall.isStatic=true;
    rwall.mass = 50.0;
    rwall.material = "hard";

    Collider uwall;
    uwall.shape=1;
    uwall.x=30.0;
    uwall.y=0.0;
    uwall.radius=740.0;
    uwall.radius2=30.0;
    uwall.isStatic=true;
    uwall.mass = 50.0;
    uwall.material = "hard";

    Collider goal;
    goal.shape=1;
    goal.x=350.0;
    goal.y=350.0;
    goal.radius=70.0;
    goal.radius2=110.0;
    goal.isStatic=true;
    goal.mass = 50.0;
    goal.material = "hard";

    Collider goal1;
    goal1.shape=1;
    goal1.x=350.0;
    goal1.y=720.0;
    goal1.radius=50.0;
    goal1.radius2=50.0;
    goal1.isStatic=true;
    goal1.mass = 50.0;
    goal1.material = "hard";

    Collider goal2;
    goal2.shape=1;
    goal2.x=170.0;
    goal2.y=550.0;
    goal2.radius=70.0;
    goal2.radius2=100.0;
    goal2.isStatic=true;
    goal2.mass = 50.0;
    goal2.material = "hard";

    Collider goal3;
    goal3.shape=1;
    goal3.x=350.0;
    goal3.y=385.0;
    goal3.radius=100.0;
    goal3.radius2=100.0;
    goal3.isStatic=true;
    goal3.mass = 50.0;
    goal3.material = "hard";

    Collider lgoal2;
    lgoal2.shape=1;
    lgoal2.x=goal2.x-20;
    lgoal2.y=goal2.y;
    lgoal2.radius=20.0;
    lgoal2.radius2=goal2.radius2;
    lgoal2.isStatic=true;
    lgoal2.mass = 50.0;
    lgoal2.material = "hard";

    Collider ugoal2;
    ugoal2.shape=1;
    ugoal2.x=lgoal2.x;
    ugoal2.y=lgoal2.y+lgoal2.radius2;
    ugoal2.radius=goal2.radius+40;
    ugoal2.radius2=20.0;
    ugoal2.isStatic=true;
    ugoal2.mass = 50.0;
    ugoal2.material = "hard";

    Collider rgoal2;
    rgoal2.shape=1;
    rgoal2.x=goal2.x+goal2.radius;
    rgoal2.y=goal2.y;
    rgoal2.radius=20.0;
    rgoal2.radius2=lgoal2.radius2;
    rgoal2.isStatic=true;
    rgoal2.mass = 50.0;
    rgoal2.material = "hard";

    Collider lgoal;
    lgoal.shape=1;
    lgoal.x=330.0;
    lgoal.y=350.0;
    lgoal.radius=20.0;
    lgoal.radius2=110.0;
    lgoal.isStatic=true;
    lgoal.mass = 50.0;
    lgoal.material = "hard";

    Collider ugoal;
    ugoal.shape=1;
    ugoal.x=330.0;
    ugoal.y=460.0;
    ugoal.radius=110.0;
    ugoal.radius2=20.0;
    ugoal.isStatic=true;
    ugoal.mass = 50.0;
    ugoal.material = "hard";

    Collider rgoal;
    rgoal.shape=1;
    rgoal.x=420.0;
    rgoal.y=350.0;
    rgoal.radius=20.0;
    rgoal.radius2=110.0;
    rgoal.isStatic=true;
    rgoal.mass = 50.0;
    rgoal.material = "hard";

    Collider lgoal3;
    lgoal3.shape=1;
    lgoal3.x=goal3.x-20;
    lgoal3.y=goal3.y;
    lgoal3.radius=20.0;
    lgoal3.radius2=goal3.radius2;
    lgoal3.isStatic=true;
    lgoal3.mass = 50.0;
    lgoal3.material = "hard";

    Collider ugoal3;
    ugoal3.shape=1;
    ugoal3.x=lgoal3.x;
    ugoal3.y=lgoal3.y+lgoal3.radius2;
    ugoal3.radius=goal3.radius+40;
    ugoal3.radius2=20.0;
    ugoal3.isStatic=true;
    ugoal3.mass = 50.0;
    ugoal3.material = "hard";

    Collider rgoal3;
    rgoal3.shape=1;
    rgoal3.x=goal3.x+goal3.radius;
    rgoal3.y=goal3.y;
    rgoal3.radius=20.0;
    rgoal3.radius2=lgoal3.radius2;
    rgoal3.isStatic=true;
    rgoal3.mass = 50.0;
    rgoal3.material = "hard";

    Collider plat;
    plat.shape=1;
    plat.x=480.0;
    plat.y=320.0;
    plat.radius=200.0;
    plat.radius2=20.0;
    plat.isStatic=true;
    plat.mass = 50.0;
    plat.material = "soft";

    Collider plat2;
    plat2.shape=1;
    plat2.x=600.0;
    plat2.y=280.0;
    plat2.radius=80.0;
    plat2.radius2=20.0;
    plat2.isStatic=true;
    plat2.mass = 50.0;
    plat2.material = "soft";

    Collider plat3;
    plat3.shape=1;
    plat3.x=200.0;
    plat3.y=400.0;
    plat3.radius=80.0;
    plat3.radius2=20.0;
    plat3.isStatic=true;
    plat3.mass = 50.0;
    plat3.material = "soft";

    Collider plat4;
    plat4.shape=1;
    plat4.x=680.0;
    plat4.y=200.0;
    plat4.radius=100.0;
    plat4.radius2=20.0;
    plat4.isStatic=true;
    plat4.mass = 50.0;
    plat4.material = "hard";

    Collider plat5;
    plat5.shape=1;
    plat5.x=400.0;
    plat5.y=100.0;
    plat5.radius=50.0;
    plat5.radius2=700.0;
    plat5.isStatic=true;
    plat5.mass = 50.0;
    plat5.material = "hard";

    Collider plat6;
    plat6.shape=1;
    plat6.x=380.0;
    plat6.y=0.0;
    plat6.radius=90.0;
    plat6.radius2=30.0;
    plat6.isStatic=true;
    plat6.mass = 50.0;
    plat6.material = "web";

    Collider plat7;
    plat7.shape=1;
    plat7.x=680.0;
    plat7.y=100.0;
    plat7.radius=100.0;
    plat7.radius2=20.0;
    plat7.isStatic=true;
    plat7.mass = 50.0;
    plat7.material = "hard";

    Collider plat8;
    plat8.shape=1;
    plat8.x=30.0;
    plat8.y=525.0;
    plat8.radius=60.0;
    plat8.radius2=10;
    plat8.isStatic=true;
    plat8.mass = 50.0;
    plat8.material="hard";

    Collider plat9;
    plat9.shape=1;
    plat9.x=370.0;
    plat9.y=125.0;
    plat9.radius=60.0;
    plat9.radius2=10;
    plat9.isStatic=true;
    plat9.mass = 50.0;
    plat9.material="hard";

    Collider plat10;
    plat10.shape=1;
    plat10.x=500.0;
    plat10.y=380.0;
    plat10.radius=170.0;
    plat10.radius2=15;
    plat10.isStatic=true;
    plat10.mass = 50.0;
    plat10.material="soft";

    Collider plat11;
    plat11.shape=1;
    plat11.x=130.0;
    plat11.y=380.0;
    plat11.radius=170.0;
    plat11.radius2=15;
    plat11.isStatic=true;
    plat11.mass = 50.0;
    plat11.material="soft";

    Collider plat12;
    plat12.shape=1;
    plat12.x=11.0;
    plat12.y=340.0;
    plat12.radius=20.0;
    plat12.radius2=40;
    plat12.isStatic=true;
    plat12.mass = 50.0;
    plat12.material="web";

    Collider plat13;
    plat13.shape=1;
    plat13.x=769.0;
    plat13.y=340.0;
    plat13.radius=20.0;
    plat13.radius2=40;
    plat13.isStatic=true;
    plat13.mass = 50.0;
    plat13.material="web";

    Collider plat14;
    plat14.shape=1;
    plat14.x=370.0;
    plat14.y=135.0;
    plat14.radius=60.0;
    plat14.radius2=15;
    plat14.isStatic=true;
    plat14.mass = 50.0;
    plat14.material="web";


    //initializing all the the graphics objects
    CircleShape player;
    player.setPosition(p1.x, p1.y);
    player.setRadius(p1.radius); 
    player.setFillColor(Color::Green);

    CircleShape ball_1;
    ball_1.setPosition(p2.x, p2.y);
    ball_1.setRadius(p2.radius);
    ball_1.setFillColor(Color::Red);

    CircleShape ball_2;
    ball_2.setPosition(p3.x, p3.y);
    ball_2.setRadius(p3.radius);
    ball_2.setFillColor(Color::Red);

    RectangleShape ground_1;
    ground_1.setPosition(lwall.x, lwall.y);
    ground_1.setSize(Vector2f(lwall.radius,lwall.radius2)); 
    ground_1.setFillColor(gray);

    RectangleShape ground_2;
    ground_2.setPosition(bwall.x, bwall.y);
    ground_2.setSize(Vector2f(bwall.radius,bwall.radius2)); 
    ground_2.setFillColor(gray);

    RectangleShape ground_3;
    ground_3.setPosition(rwall.x, rwall.y);
    ground_3.setSize(Vector2f(rwall.radius,rwall.radius2)); 
    ground_3.setFillColor(gray);

    RectangleShape ground_4;
    ground_4.setPosition(uwall.x, uwall.y);
    ground_4.setSize(Vector2f(uwall.radius,uwall.radius2)); 
    ground_4.setFillColor(gray);

    RectangleShape goal_1;
    goal_1.setPosition(goal.x, goal.y);
    goal_1.setSize(Vector2f(goal.radius, goal.radius2));
    goal_1.setFillColor(Color::Blue);

    RectangleShape goal_2;
    goal_2.setPosition(goal1.x, goal1.y);
    goal_2.setSize(Vector2f(goal1.radius, goal1.radius2));
    goal_2.setFillColor(Color::Blue);

    RectangleShape goal_3;
    goal_3.setPosition(goal2.x,goal2.y);
    goal_3.setSize(Vector2f(goal2.radius,goal2.radius2));
    goal_3.setFillColor(Color::Blue);

    RectangleShape goal_4;
    goal_4.setPosition(goal3.x,goal3.y);
    goal_4.setSize(Vector2f(goal3.radius,goal3.radius2));
    goal_4.setFillColor(Color::Blue);

    RectangleShape goal_wall1;
    goal_wall1.setPosition(lgoal.x, lgoal.y);
    goal_wall1.setSize(Vector2f(lgoal.radius, lgoal.radius2));
    goal_wall1.setFillColor(gray);

    RectangleShape goal_wall2;
    goal_wall2.setPosition(ugoal.x, ugoal.y);
    goal_wall2.setSize(Vector2f(ugoal.radius, ugoal.radius2));
    goal_wall2.setFillColor(gray);

    RectangleShape goal_wall3;
    goal_wall3.setPosition(rgoal.x, rgoal.y);
    goal_wall3.setSize(Vector2f(rgoal.radius, rgoal.radius2));
    goal_wall3.setFillColor(gray);

    RectangleShape goal_wall4;
    goal_wall4.setPosition(lgoal2.x, lgoal2.y);
    goal_wall4.setSize(Vector2f(lgoal2.radius, lgoal2.radius2));
    goal_wall4.setFillColor(gray);

    RectangleShape goal_wall5;
    goal_wall5.setPosition(ugoal2.x, ugoal2.y);
    goal_wall5.setSize(Vector2f(ugoal2.radius, ugoal2.radius2));
    goal_wall5.setFillColor(gray);

    RectangleShape goal_wall6;
    goal_wall6.setPosition(rgoal2.x, rgoal2.y);
    goal_wall6.setSize(Vector2f(rgoal2.radius, rgoal2.radius2));
    goal_wall6.setFillColor(gray);

    RectangleShape goal_wall7;
    goal_wall7.setPosition(lgoal3.x, lgoal3.y);
    goal_wall7.setSize(Vector2f(lgoal3.radius, lgoal3.radius2));
    goal_wall7.setFillColor(gray);

    RectangleShape goal_wall8;
    goal_wall8.setPosition(ugoal3.x, ugoal3.y);
    goal_wall8.setSize(Vector2f(ugoal3.radius, ugoal3.radius2));
    goal_wall8.setFillColor(gray);

    RectangleShape goal_wall9;
    goal_wall9.setPosition(rgoal3.x, rgoal3.y);
    goal_wall9.setSize(Vector2f(rgoal3.radius, rgoal3.radius2));
    goal_wall9.setFillColor(gray);

    RectangleShape plat_1;
    plat_1.setPosition(plat.x, plat.y);
    plat_1.setSize(Vector2f(plat.radius, plat.radius2));
    plat_1.setFillColor(Color::Cyan);

    RectangleShape plat_2;
    plat_2.setPosition(plat2.x, plat2.y);
    plat_2.setSize(Vector2f(plat2.radius, plat2.radius2));
    plat_2.setFillColor(Color::Cyan);

    RectangleShape plat_3;
    plat_3.setPosition(plat3.x, plat3.y);
    plat_3.setSize(Vector2f(plat3.radius, plat3.radius2));
    plat_3.setFillColor(Color::Cyan);

    RectangleShape plat_4;
    plat_4.setPosition(plat4.x, plat4.y);
    plat_4.setSize(Vector2f(plat4.radius, plat4.radius2));
    plat_4.setFillColor(gray);

    RectangleShape plat_5;
    plat_5.setPosition(plat5.x, plat5.y);
    plat_5.setSize(Vector2f(plat5.radius, plat5.radius2));
    plat_5.setFillColor(gray);

    RectangleShape plat_6;
    plat_6.setPosition(plat6.x, plat6.y);
    plat_6.setSize(Vector2f(plat6.radius, plat6.radius2));
    plat_6.setFillColor(Color::White);

    RectangleShape plat_7;
    plat_7.setPosition(plat7.x, plat7.y);
    plat_7.setSize(Vector2f(plat7.radius, plat7.radius2));
    plat_7.setFillColor(gray);

    RectangleShape plat_8;
    plat_8.setPosition(plat8.x,plat8.y);
    plat_8.setSize(Vector2f(plat8.radius, plat8.radius2));
    plat_8.setFillColor(gray);

    RectangleShape plat_9;
    plat_9.setPosition(plat9.x,plat9.y);
    plat_9.setSize(Vector2f(plat9.radius, plat9.radius2));
    plat_9.setFillColor(gray);

    RectangleShape plat_10;
    plat_10.setPosition(plat10.x,plat10.y);
    plat_10.setSize(Vector2f(plat10.radius, plat10.radius2));
    plat_10.setFillColor(Color::Cyan);

    RectangleShape plat_11;
    plat_11.setPosition(plat11.x,plat11.y);
    plat_11.setSize(Vector2f(plat11.radius, plat11.radius2));
    plat_11.setFillColor(Color::Cyan);

    RectangleShape plat_12;
    plat_12.setPosition(plat12.x,plat12.y);
    plat_12.setSize(Vector2f(plat12.radius, plat12.radius2));
    plat_12.setFillColor(Color::White);

    RectangleShape plat_13;
    plat_13.setPosition(plat13.x,plat13.y);
    plat_13.setSize(Vector2f(plat13.radius, plat13.radius2));
    plat_13.setFillColor(Color::White);

    RectangleShape plat_14;
    plat_14.setPosition(plat14.x,plat14.y);
    plat_14.setSize(Vector2f(plat14.radius, plat14.radius2));
    plat_14.setFillColor(Color::White);

    RectangleShape disp_1;
    disp_1.setPosition(d1.x,d1.y);
    disp_1.setSize(Vector2f(20,20));
    disp_1.setFillColor(Color::Yellow);

    RectangleShape disp_2;
    disp_2.setPosition(d2.x,d2.y);
    disp_2.setSize(Vector2f(20,20));
    disp_2.setFillColor(Color::Yellow);

    RectangleShape arrow_1;
    arrow_1.setPosition(arrow.x, arrow.y);
    arrow_1.setSize(Vector2f(arrow.radius, arrow.radius2));
    arrow_1.setFillColor(brown);

    RectangleShape arrow_2;
    arrow_2.setPosition(arrow2.x, arrow2.y);
    arrow_2.setSize(Vector2f(arrow2.radius, arrow2.radius2));
    arrow_2.setFillColor(brown);

    RectangleShape button_1;
    button_1.setPosition(button1.x, button1.y);
    button_1.setSize(Vector2f(button1.radius, button1.radius2));
    button_1.setFillColor(purple);

    RectangleShape button_2;
    button_2.setPosition(button2.x, button2.y);
    button_2.setSize(Vector2f(button2.radius, button2.radius2));
    button_2.setFillColor(purple);

    //sets what state the game starts in and initialzed moves tracker
    int state = 0;
    int moves = 0;

    Font font;
    if (!font.loadFromFile(RES_FONT)) return EXIT_FAILURE;          // could not load font

    RenderWindow window(VideoMode(800, 800), "Goal Chaser");

    //initialized the Collider arrays for each object, make sure to keep track of the size per level.

    Collider* colliders[] = {&p1, &lwall, &bwall, &rwall, &uwall, &p2, &lgoal, &ugoal, &rgoal, &plat, &plat3, &plat4};

    Collider* colliders1[] = {&p1, &lwall, &bwall, &rwall, &uwall, &plat5, &plat6};

    Collider* colliders2[] = {&p1, &p3, &plat7, &lwall, &bwall, &rwall, &uwall, &lgoal2, &ugoal2, &rgoal2, &plat8};

    Collider* colliders3[] = {&p1, &p3, &lwall, &bwall, &rwall, &uwall, &plat9, &plat10, &plat11, &plat12, &plat13, &plat14, &lgoal3, &ugoal3, &rgoal3};

    while(window.isOpen()){
        Event event;
        while (window.pollEvent(event))
        {
            if (event.type == Event::Closed)
                window.close();
        }
        if(state==0){
            //very standard start screen
            window.clear();
            Text Title("Goal Chaser", font, 50);
            Text desc("Try to get all the balls into the goal", font, 30);
            Text controls("Click LMB and drag to move when ball is at rest", font, 25);
            Text controls1("You control the green ball", font, 25);
            Text start("Press Enter to start", font, 30);
            controls.setFillColor(sf::Color::Red);
            controls1.setFillColor(sf::Color::Green);
            Title.setPosition(210,100);
            desc.setPosition(140, 200);
            controls.setPosition(100,250);
            controls1.setPosition(200,300);
            start.setPosition(210, 400);
            window.draw(Title);
            window.draw(desc);
            window.draw(controls);
            window.draw(controls1);
            window.draw(start);
            window.display();
            //start!
            if(sf::Keyboard::isKeyPressed(sf::Keyboard::Enter)){
                state = 1;
                resetPlayer(p1, state);
                p2.x=600.0;
                p2.y=100.0;
                p2.isStatic=false;
                p2.tempStatic=false;
                p2.velocity_y = 1.0;
                p2.velocity_x = 0.5;
                p2.acceleration_y = gravity;
                p2.acceleration_x = -70.0;
                p3.x=680.0;
                p3.y=50.0;
                p3.radius=20.0;
                p3.radius2=0.0; 
                p3.isStatic=false;
                p3.tempStatic=false;
                p3.velocity_y = 0.1;
                p3.velocity_x = 0.1;
                p3.acceleration_y = gravity;
                p3.acceleration_x = 0.0;
                moves=0;
                clock.restart();
            }
        }

        if(state==1){
            //win condition
            if(collision(&p1,&goal) && collision(&p2, &goal)){
                state=3;
                moves=0;
                p1.x=700;
                p1.y=700;
                p1.velocity_x=0.0;
                p1.velocity_y=0.0;
                p1.acceleration_x=0.0;
                p1.acceleration_y=gravity;
                p1.isStatic=false;
                p1.tempStatic=false;
            }
            //reset command
            if(Keyboard::isKeyPressed(Keyboard::R)){
                resetPlayer(p1, state);
                p2.x=600.0;
                p2.y=100.0;
                p2.radius=20.0;
                p2.radius2=0.0; 
                p2.isStatic=false;
                p2.tempStatic=false;
                p2.velocity_y = 1.0;
                p2.velocity_x = 0.5;
                p2.acceleration_y = gravity;
                p2.acceleration_x = -70.0;
                moves=0;
            }
            //ran out of moves
            if(moves>7 && p1.tempStatic){
                resetPlayer(p1,state);
                p2.x=600.0;
                p2.y=100.0;
                p2.radius=20.0;
                p2.radius2=0.0; 
                p2.isStatic=false;
                p2.tempStatic=false;
                p2.velocity_y = 1.0;
                p2.velocity_x = 0.5;
                p2.acceleration_y = gravity;
                p2.acceleration_x = -70.0;
                moves=0;
            }
            //how collision works for all the members of the level
            do_collisions(colliders, 12);

            float DT=(clock.getElapsedTime().asSeconds())*1.5;
            
            //how the player is able to move
            Vector2f movement = player_move(p1);
            if(abs(movement.x)>1 || abs(movement.y)>1){
                moves++;
            }
            p1.velocity_x+=movement.x;
            p1.velocity_y+=movement.y;
            velocityUpdate(&p1, DT);
            velocityUpdate(&p2,DT);

            clock.restart();

            Text moveCounter("Moves Left: "+std::to_string(8-moves), font, 40);
            moveCounter.setPosition(40,40);

            //drawing everything
            player.setPosition(p1.x, p1.y);
            ball_1.setPosition(p2.x, p2.y);
            window.clear();
            window.draw(moveCounter);
            window.draw(player);
            window.draw(ball_1);
            window.draw(goal_1);
            window.draw(goal_wall1);
            window.draw(goal_wall2);
            window.draw(goal_wall3);
            window.draw(ground_1);
            window.draw(ground_2);
            window.draw(ground_3);
            window.draw(ground_4);
            window.draw(plat_1);
            window.draw(plat_3);
            window.draw(plat_4);
            window.draw(player);
            window.draw(ball_1);
            window.display();
            //rinse and repeat for all the other levels
            
        }

        if(state==3){
            Text moveCounter("Moves Left: "+std::to_string(4-moves), font, 40);
            moveCounter.setPosition(40,40);

            if(Keyboard::isKeyPressed(Keyboard::R)){
                resetPlayer(p1, state);
                moves=0;
            }
            if(moves>3 && p1.tempStatic){
                resetPlayer(p1, state);
                moves=0;
            }
            do_collisions(colliders1, 7);
            if(collision(&p1,&goal1)){
                state=4;
                moves=0;
                p1.x=700;
                p1.y=700;
                p1.velocity_x=0.0;
                p1.velocity_y=0.0;
                p1.acceleration_x=0.0;
                p1.acceleration_y=gravity;
                p1.isStatic=false;
                p1.tempStatic=false;
            }
            float DT=(clock.getElapsedTime().asSeconds())*1.5;
            Vector2f movement = player_move(p1);
            if(abs(movement.x)>1 || abs(movement.y)>1){
                moves++;
            }
            p1.velocity_x+=movement.x;
            p1.velocity_y+=movement.y;
            velocityUpdate(&p1, DT);

            clock.restart();

            player.setPosition(p1.x, p1.y);
            window.clear();
            window.draw(player);
            window.draw(ground_1);
            window.draw(ground_2);
            window.draw(ground_3);
            window.draw(ground_4);
            window.draw(goal_2);
            window.draw(plat_5);
            window.draw(plat_6);
            window.draw(moveCounter);
            window.display();
        }
        if(state==4){
            Text moveCounter("Moves Left: "+std::to_string(6-moves), font, 40);
            moveCounter.setPosition(40,40);

            if(Keyboard::isKeyPressed(Keyboard::R)){
                resetPlayer(p1, 3);
                p3.x=680.0;
                p3.y=50.0;
                p3.isStatic=false;
                p3.tempStatic=false;
                p3.velocity_y = 0.1;
                p3.velocity_x = 0.1;
                p3.acceleration_y = gravity;
                p3.acceleration_x = 0.0;
                arrow.x=d1.x+5;
                arrow.y=d1.y+11;
                arrow.velocity_x=0.0;
                d1.hasFired=false;
                arrow.acceleration_x=0.0;

                moves=0;
            }
            if(moves>5 && p1.tempStatic){
                resetPlayer(p1, 3);
                p3.x=680.0;
                p3.y=50.0;
                p3.isStatic=false;
                p3.tempStatic=false;
                p3.velocity_y = 0.1;
                p3.velocity_x = 0.1;
                p3.acceleration_y = gravity;
                p3.acceleration_x = 0.0;
                arrow.x=d1.x+5;
                arrow.y=d1.y+11;
                arrow.velocity_x=0.0;
                d1.hasFired=false;
                arrow.acceleration_x=0.0;
                moves=0;
            }
            do_collisions(colliders2, 11);

            if(collision(&p1, &button1) && !d1.hasFired){
                arrow.velocity_x=-100.0;
                arrow.acceleration_x=-50000;
                d1.hasFired=true;
            }
            if(collision(&p3,&arrow)){
                collisions(&p3, &arrow);
                arrow.x=d1.x+5;
                arrow.y=d1.y+11;
                arrow.velocity_x=0.0;
                d1.hasFired=false;
                arrow.acceleration_x=0.0;
            }
            if(collision(&arrow,&lwall)){
                arrow.x=d1.x+5;
                arrow.y=d1.y+11;
                arrow.velocity_x=0.0;
                d1.hasFired=false;
                arrow.acceleration_x=0.0;
            }

            if(collision(&p1,&goal2) && collision(&p3, &goal2)){
                state=5;
                moves=0;
                p1.x=400;
                p1.y=700;
                p1.velocity_x=0.0;
                p1.velocity_y=0.0;
                p1.acceleration_x=0.0;
                p1.acceleration_y=gravity;
                p1.isStatic=false;
                p1.tempStatic=false;
                p3.x=380.0;
                p3.y=75.0;
                p3.isStatic=false;
                p3.tempStatic=false;
                p3.velocity_y = 0.1;
                p3.velocity_x = 0.1;
                p3.acceleration_y = gravity;
                p3.acceleration_x = 0.0;
                d1.y=100;
                disp_1.setPosition(d1.x,d1.y);
                arrow.y=d1.y+10;
            }

            float DT=(clock.getElapsedTime().asSeconds())*1.5;
            Vector2f movement = player_move(p1);
            if(abs(movement.x)>1 || abs(movement.y)>1){
                moves++;
            }
            p1.velocity_x+=movement.x;
            p1.velocity_y+=movement.y;
            velocityUpdate(&p1, DT);
            velocityUpdate(&p3, DT);
            if(d1.hasFired){
                velocityUpdate(&arrow, DT);
            }

            clock.restart();

            player.setPosition(p1.x, p1.y);
            ball_2.setPosition(p3.x, p3.y);
            window.clear();
            if(d1.hasFired){
                arrow_1.setPosition(arrow.x, arrow.y);
                window.draw(arrow_1);
            }
            window.draw(goal_3);
            window.draw(player);
            window.draw(ball_2);
            window.draw(plat_8);
            window.draw(ground_1);
            window.draw(ground_2);
            window.draw(ground_3);
            window.draw(ground_4);
            window.draw(button_1);
            window.draw(goal_wall4);
            window.draw(goal_wall5);
            window.draw(goal_wall6);
            window.draw(plat_7);
            window.draw(moveCounter);
            window.draw(disp_1);
            window.display();
        }

        if(state==5){

            Text moveCounter("Moves Left: "+std::to_string(10-moves), font, 40);
            moveCounter.setPosition(40,40);

            if(moves>9 && p1.tempStatic){
                resetPlayer(p1, 3);
                moves=0;
                p1.x=400;
                p1.y=700;
                p1.velocity_x=0.0;
                p1.velocity_y=0.0;
                p1.acceleration_x=0.0;
                p1.acceleration_y=gravity;
                p1.isStatic=false;
                p1.tempStatic=false;
                p3.x=380.0;
                p3.y=75.0;
                p3.isStatic=false;
                p3.tempStatic=false;
                p3.velocity_y = 0.1;
                p3.velocity_x = 0.1;
                p3.acceleration_y = gravity;
                p3.acceleration_x = 0.0;
            }

            if(Keyboard::isKeyPressed(Keyboard::R)){
                resetPlayer(p1, state);
                p3.x=380.0;
                p3.y=75.0;
                p3.isStatic=false;
                p3.tempStatic=false;
                p3.velocity_y = 0.1;
                p3.velocity_x = 0.1;
                p3.acceleration_y = gravity;
                p3.acceleration_x = 0.0;
                arrow.x=d1.x+5;
                arrow.y=d1.y+11;
                arrow.velocity_x=0.0;
                d1.hasFired=false;
                arrow.acceleration_x=0.0;
                arrow2.x=d2.x+5;
                arrow2.y=d2.y+11;
                arrow2.velocity_x=0.0;
                d2.hasFired=false;
                arrow2.acceleration_x=0.0;
                moves=0;
            }
            
            do_collisions(colliders3, 15);

            if(collision(&p1,&goal3) && collision(&p3, &goal3)){
                state=2;
                moves=0;
            }

            if(collision(&p1, &button1) && !d1.hasFired){
                arrow.velocity_x=-100.0;
                arrow.acceleration_x=-40000;
                d1.hasFired=true;
            }
            if(collision(&p1, &button2) && !d2.hasFired){
                arrow2.velocity_x=100.0;
                arrow2.acceleration_x=40000;
                d2.hasFired=true;
            }

            if(collision(&p3,&arrow)){
                collisions(&p3, &arrow);
                arrow.x=d1.x+5;
                arrow.y=d1.y+11;
                arrow.velocity_x=0.0;
                d1.hasFired=false;
                arrow.acceleration_x=0.0;
            }
            if(collision(&arrow,&lwall)){
                arrow.x=d1.x+5;
                arrow.y=d1.y+11;
                arrow.velocity_x=0.0;
                d1.hasFired=false;
                arrow.acceleration_x=0.0;
            }
            if(collision(&p3,&arrow2)){
                collisions(&p3, &arrow2);
                arrow2.x=d2.x+5;
                arrow2.y=d2.y+11;
                arrow2.velocity_x=0.0;
                d2.hasFired=false;
                arrow2.acceleration_x=0.0;
            }
            if(collision(&arrow2,&rwall)){
                arrow2.x=d2.x+5;
                arrow2.y=d2.y+11;
                arrow2.velocity_x=0.0;
                d2.hasFired=false;
                arrow2.acceleration_x=0.0;
            }

            float DT=(clock.getElapsedTime().asSeconds())*1.5;
            Vector2f movement = player_move(p1);
            if(abs(movement.x)>1 || abs(movement.y)>1){
                moves++;
            }
            p1.velocity_x+=movement.x;
            p1.velocity_y+=movement.y;
            velocityUpdate(&p1, DT);
            velocityUpdate(&p3, DT);
            if(d1.hasFired){
                velocityUpdate(&arrow, DT);
            }
            if(d2.hasFired){
                velocityUpdate(&arrow2, DT);
            }
            clock.restart();
            window.clear();
            player.setPosition(p1.x,p1.y);
            ball_2.setPosition(p3.x,p3.y);
            if(d1.hasFired){
                arrow_1.setPosition(arrow.x, arrow.y);
                window.draw(arrow_1);
            }
            if(d2.hasFired){
                arrow_2.setPosition(arrow2.x, arrow2.y);
                window.draw(arrow_2);
            }
            window.draw(goal_4);
            window.draw(player);
            window.draw(ball_2);
            window.draw(ground_1);
            window.draw(ground_2);
            window.draw(ground_3);
            window.draw(ground_4);
            window.draw(plat_9);
            window.draw(plat_10);
            window.draw(plat_11);
            window.draw(plat_12);
            window.draw(plat_13);
            window.draw(plat_14);
            window.draw(disp_1);
            window.draw(disp_2);
            window.draw(button_1);
            window.draw(button_2);
            window.draw(moveCounter);
            window.draw(goal_wall7);
            window.draw(goal_wall8);
            window.draw(goal_wall9);
            window.display();
        }
        if(state==2){
            
            window.clear();
            //sf::Text congrats("null", font, 50);
            sf::Text win("YOU WIN!", font, 45);
            sf::Text title("Press T to return to the title screen",font, 30);
            sf::Text pa("Press P to play again!", font, 30);
            win.setPosition(300, 150);
            title.setPosition(150, 250);
            pa.setPosition(250, 300);
            //window.draw(congrats);
            window.draw(win);
            window.draw(title);
            window.draw(pa);
            window.display();

            if(Keyboard::isKeyPressed(Keyboard::T)){
                state = 0;
            }
            if(Keyboard::isKeyPressed(Keyboard::P)){
                state = 1;
                resetPlayer(p1,state);
                p2.x=600.0;
                p2.y=100.0;
                p2.radius=20.0;
                p2.radius2=0.0; 
                p2.isStatic=false;
                p2.tempStatic=false;
                p2.velocity_y = 1.0;
                p2.velocity_x = 0.5;
                p2.acceleration_y = gravity;
                p2.acceleration_x = -70.0;
                p2.mass = 5.0;
                p2.material = "rubber";

                p3.x=680.0;
                p3.y=50.0;
                p3.radius=20.0;
                p3.radius2=0.0; 
                p3.isStatic=false;
                p3.tempStatic=false;
                p3.velocity_y = 0.1;
                p3.velocity_x = 0.1;
                p3.acceleration_y = gravity;
                p3.acceleration_x = 0.0;
                moves=0;
                clock.restart();
            }
        }

        
    }
    return 0;
}

