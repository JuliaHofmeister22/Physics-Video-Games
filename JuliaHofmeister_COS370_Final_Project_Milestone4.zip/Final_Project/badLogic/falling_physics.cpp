#include <SFML/Graphics.hpp>
#include <algorithm>
#include <sstream>
#include <unistd.h>
#include <ctime>
#include <string>
#include <iostream>
#include <queue>
#include "physicsEngine.h"

using namespace sf;

RenderWindow window(VideoMode(800, 800), "Falling Physics");

int scene = 0;

int main()
{
    Font arial;
    if (!arial.loadFromFile("resources/arial.ttf")) return EXIT_FAILURE; //fontspace credits

    Text instruct("Click on BLUE objects to make them disappear!",arial, 20);
    instruct.setPosition(190, 300);
    instruct.setFillColor(Color::White);

    Text instruct2("Land the WHITE ball on the orange platform to win.",arial, 20);
    instruct2.setPosition(170, 270);
    instruct2.setFillColor(Color::White);

    Text title("Falling Physics",arial,80);
    title.setPosition(150, 150);
    title.setFillColor(Color::Green);

    Text won("You Won!",arial,80);
    won.setPosition(200, 150);
    won.setFillColor(Color::Green);

    Text fail("You Failed",arial,80);
    fail.setPosition(200, 150);
    fail.setFillColor(Color::Red);

    Text level1_text("Level 1",arial,20);
    level1_text.setPosition(220, 520);
    level1_text.setFillColor(Color::Black);

    Text level2_text("Level 2",arial,20);
    level2_text.setPosition(520, 520);
    level2_text.setFillColor(Color::Black);

    Text home("Home screen",arial,15);
    home.setPosition(360, 710);
    home.setFillColor(Color::Black);

    Text restart("Restart",arial,10);
    restart.setPosition(25, 760);
    restart.setFillColor(Color::Black);
    
    
    
    Clock clock;

    Collider ball;
    ball.shape=0;
    ball.x=800.0;
    ball.y=-50.0;
    ball.radius=20.0;
    ball.radius2=0.0; 
    ball.isStatic=false;
    ball.tempStatic=false;
    ball.velocity_y = 2.0;
    ball.velocity_x = -5.0;
    ball.acceleration_y = gravity;
    ball.acceleration_x = -10.0;
    ball.mass = 10.0;
    ball.material = "rubber";
    ball.canDisappear = false;

    Collider ball2;
    ball2.shape=0;
    ball2.x=100.0;
    ball2.y=-50.0;
    ball2.radius=20.0;
    ball2.radius2=0.0; 
    ball2.isStatic=false;
    ball2.tempStatic=false;
    ball2.velocity_y = 2.0;
    ball2.velocity_x = -1.0;
    ball2.acceleration_y = gravity;
    ball2.acceleration_x = -10.0;
    ball2.mass = 10.0;
    ball2.material = "rubber";
    ball2.canDisappear = false;

    Collider ledge;
    ledge.shape=1;
    ledge.x=690.0;
    ledge.y=220.0;
    ledge.radius=80.0;
    ledge.radius2=20.0;
    ledge.isStatic=true;
    ledge.mass = 40.0;
    ledge.material = "hard";
    ledge.canDisappear = false;

    Collider ledge2;
    ledge2.shape=1;
    ledge2.x=50.0;
    ledge2.y=140.0;
    ledge2.radius=10.0;
    ledge2.radius2=50.0;
    ledge2.isStatic=true;
    ledge2.mass = 40.0;
    ledge2.material = "hard";
    ledge2.canDisappear = true;

    Collider ledge3;
    ledge3.shape=1;
    ledge3.x=740.0;
    ledge3.y=350.0;
    ledge3.radius=10.0;
    ledge3.radius2=50.0;
    ledge3.isStatic=true;
    ledge3.mass = 40.0;
    ledge3.material = "hard";
    ledge3.canDisappear = true;

    Collider ledge4;
    ledge4.shape=1;
    ledge4.x=600.0;
    ledge4.y=350.0;
    ledge4.radius=10.0;
    ledge4.radius2=50.0;
    ledge4.isStatic=true;
    ledge4.mass = 40.0;
    ledge4.material = "hard";
    ledge4.canDisappear = true;

    Collider ledge5;
    ledge5.shape=1;
    ledge5.x=700.0;
    ledge5.y=300.0;
    ledge5.radius=10.0;
    ledge5.radius2=50.0;
    ledge5.isStatic=true;
    ledge5.mass = 40.0;
    ledge5.material = "hard";
    ledge5.canDisappear = true;

    Collider ledge6;
    ledge6.shape=1;
    ledge6.x=640.0;
    ledge6.y=130.0;
    ledge6.radius=60.0;
    ledge6.radius2=10.0;
    ledge6.isStatic=true;
    ledge6.mass = 40.0;
    ledge6.material = "hard";
    ledge6.canDisappear = true;


    Collider ground;
    ground.shape=1;
    ground.x=0.0;
    ground.y=740.0;
    ground.radius=800.0;
    ground.radius2=60.0;
    ground.isStatic=true;
    ground.mass = 100.0;
    ground.material = "hard";
    ball.canDisappear = false;

    Collider box;
    box.shape=1;
    box.radius2=80.0;
    box.isStatic=true;
    box.mass = 40.0;
    box.material = "soft";
    box.canDisappear = true;

    Collider side;
    side.shape=1;
    side.x=200.0;
    side.y=170.0;
    side.radius=10.0;
    side.radius2=40.0;
    side.isStatic=true;
    side.mass = 40.0;
    side.material = "hard";
    side.canDisappear = true;

    Collider side2;
    side2.shape=1;
    side2.x=570.0;
    side2.y=170.0;
    side2.radius=10.0;
    side2.radius2=40.0;
    side2.isStatic=true;
    side2.mass = 40.0;
    side2.material = "hard";
    side2.canDisappear = true;

    Collider side3;
    side3.shape=1;
    side3.x=200.0;
    side3.y=370.0;
    side3.radius=40.0;
    side3.radius2=20.0;
    side3.isStatic=true;
    side3.mass = 40.0;
    side3.material = "hard";
    side3.canDisappear = true;

    Collider side4;
    side4.shape=1;
    side4.x=270.0;
    side4.y=450.0;
    side4.radius=60.0;
    side4.radius2=20.0;
    side4.isStatic=true;
    side4.mass = 40.0;
    side4.material = "hard";
    side4.canDisappear = true;

    Collider goal;
    goal.shape=1;
    goal.x=500.0;
    goal.y=660.0;
    goal.radius=80.0;
    goal.radius2=10.0;
    goal.isStatic=true;
    goal.mass = 40.0;
    goal.material = "soft";
    goal.canDisappear = false;
   
    Color gray(100,100,100);
    Color orange(255,165,100);

    CircleShape player;
    player.setPosition(ball.x, ball.y);
    player.setRadius(ball.radius); 
    player.setFillColor(Color::White);

    CircleShape redBall;
    redBall.setPosition(ball2.x, ball2.y);
    redBall.setRadius(ball2.radius); 
    redBall.setFillColor(Color::Red);

    RectangleShape ledge_1;
    ledge_1.setPosition(ledge.x, ledge.y);
    ledge_1.setSize(Vector2f(ledge.radius,ledge.radius2)); 
    ledge_1.setFillColor(Color::Green);

    RectangleShape ledge_2;
    ledge_2.setPosition(ledge2.x, ledge2.y);
    ledge_2.setSize(Vector2f(ledge2.radius,ledge2.radius2)); 
    ledge_2.setFillColor(Color::Blue);

    RectangleShape ledge_3;
    ledge_3.setPosition(ledge3.x, ledge3.y);
    ledge_3.setSize(Vector2f(ledge3.radius,ledge3.radius2)); 
    ledge_3.setFillColor(Color::Blue);

    RectangleShape ledge_4;
    ledge_4.setPosition(ledge4.x, ledge4.y);
    ledge_4.setSize(Vector2f(ledge4.radius,ledge4.radius2)); 
    ledge_4.setFillColor(Color::Blue);

    RectangleShape ledge_5;
    ledge_5.setPosition(ledge5.x, ledge5.y);
    ledge_5.setSize(Vector2f(ledge5.radius,ledge5.radius2)); 
    ledge_5.setFillColor(Color::Blue);

    RectangleShape ledge_6;
    ledge_6.setPosition(ledge6.x, ledge6.y);
    ledge_6.setSize(Vector2f(ledge6.radius,ledge6.radius2)); 
    ledge_6.setFillColor(Color::Blue);


    RectangleShape ground_1;
    ground_1.setPosition(ground.x, ground.y);
    ground_1.setSize(Vector2f(ground.radius,ground.radius2)); 
    ground_1.setFillColor(gray);

    RectangleShape goal_1;
    goal_1.setPosition(goal.x, goal.y);
    goal_1.setSize(Vector2f(goal.radius,goal.radius2)); 
    goal_1.setFillColor(orange);

    RectangleShape side_1;
    side_1.setPosition(side.x, side.y);
    side_1.setSize(Vector2f(side.radius,side.radius2)); 
    side_1.setFillColor(Color::Blue);

    RectangleShape side_2;
    side_2.setPosition(side2.x, side2.y);
    side_2.setSize(Vector2f(side2.radius,side2.radius2)); 
    side_2.setFillColor(Color::Blue);

    RectangleShape side_3;
    side_3.setPosition(side3.x, side3.y);
    side_3.setSize(Vector2f(side3.radius,side3.radius2)); 
    side_3.setFillColor(Color::Blue);

    RectangleShape side_4;
    side_4.setPosition(side4.x, side4.y);
    side_4.setSize(Vector2f(side4.radius,side4.radius2)); 
    side_4.setFillColor(Color::Blue);

    RectangleShape box_1;
    box_1.setPosition(box.x, box.y);
    box_1.setSize(Vector2f(box.radius,box.radius2)); 
    box_1.setFillColor(Color::Blue);
    //////////////////////////////////////////////////////

    Collider _ball;
    _ball.shape=0;
    _ball.x=-50.0;
    _ball.y=50.0;
    _ball.radius=20.0;
    _ball.radius2=0.0; 
    _ball.isStatic=false;
    _ball.tempStatic=false;
    _ball.velocity_y = 2.0;
    _ball.velocity_x = 60.0;
    _ball.acceleration_y = gravity;
    _ball.acceleration_x = 10.0;
    _ball.mass = 10.0;
    _ball.material = "rubber";
    _ball.canDisappear = false;

    Collider _ball2;
    _ball2.shape=0;
    _ball2.x=750.0;
    _ball2.y=-40.0;
    _ball2.radius=20.0;
    _ball2.radius2=0.0; 
    _ball2.isStatic=false;
    _ball2.tempStatic=false;
    _ball2.velocity_y = 10.0;
    _ball2.velocity_x = -5.0;
    _ball2.acceleration_y = gravity;
    _ball2.acceleration_x = -10.0;
    _ball2.mass = 10.0;
    _ball2.material = "rubber";
    _ball2.canDisappear = false;

    Collider _ball3;
    _ball3.shape=0;
    _ball3.x=350.0;
    _ball3.y=-70.0;
    _ball3.radius=20.0;
    _ball3.radius2=0.0; 
    _ball3.isStatic=false;
    _ball3.tempStatic=false;
    _ball3.velocity_y = 1.2;
    _ball3.velocity_x = -10.0;
    _ball3.acceleration_y = gravity;
    _ball3.acceleration_x = -10.0;
    _ball3.mass = 10.0;
    _ball3.material = "rubber";
    _ball3.canDisappear = false;


    Collider goal2;
    goal2.shape=1;
    goal2.x=129.0;
    goal2.y=589.0;
    goal2.radius=25.0;
    goal2.radius2=10.0;
    goal2.isStatic=true;
    goal2.mass = 40.0;
    goal2.material = "soft";
    goal2.canDisappear = false;

    Collider platform;
    platform.shape=1;
    platform.x=300.0;
    platform.y=400.0;
    platform.radius=80.0;
    platform.radius2=10.0;
    platform.isStatic=true;
    platform.mass = 40.0;
    platform.material = "hard";
    platform.canDisappear = false;

    Collider platform2;
    platform2.shape=1;
    platform2.x=600.0;
    platform2.y=300.0;
    platform2.radius=80.0;
    platform2.radius2=10.0;
    platform2.isStatic=true;
    platform2.mass = 40.0;
    platform2.material = "hard";
    platform2.canDisappear = true;

    Collider platform3;
    platform3.shape=1;
    platform3.x=470.0;
    platform3.y=500.0;
    platform3.radius=80.0;
    platform3.radius2=10.0;
    platform3.isStatic=true;
    platform3.mass = 40.0;
    platform3.material = "hard";
    platform3.canDisappear = true;

    Collider platform4;
    platform4.shape=1;
    platform4.x=170.0;
    platform4.y=240.0;
    platform4.radius=80.0;
    platform4.radius2=10.0;
    platform4.isStatic=true;
    platform4.mass = 40.0;
    platform4.material = "hard";
    platform4.canDisappear = true;

    Collider wall;
    wall.shape=1;
    wall.x=700.0;
    wall.y=390.0;
    wall.radius=10.0;
    wall.radius2=60.0;
    wall.isStatic=true;
    wall.mass = 40.0;
    wall.material = "hard";
    wall.canDisappear = true;

    Collider wall2;
    wall2.shape=1;
    wall2.x=150.0;
    wall2.y=680.0;
    wall2.radius=10.0;
    wall2.radius2=40.0;
    wall2.isStatic=true;
    wall2.mass = 40.0;
    wall2.material = "hard";
    wall2.canDisappear = true;

    Collider wall3;
    wall3.shape=1;
    wall3.x=390.0;
    wall3.y=650.0;
    wall3.radius=10.0;
    wall3.radius2=60.0;
    wall3.isStatic=true;
    wall3.mass = 40.0;
    wall3.material = "hard";
    wall3.canDisappear = true;

    Collider wall4;
    wall4.shape=1;
    wall4.x=240.0;
    wall4.y=150.0;
    wall4.radius=40.0;
    wall4.radius2=10.0;
    wall4.isStatic=true;
    wall4.mass = 40.0;
    wall4.material = "hard";
    wall4.canDisappear = true;

    Collider wall5;
    wall5.shape=1;
    wall5.x=40.0;
    wall5.y=210.0;
    wall5.radius=10.0;
    wall5.radius2=60.0;
    wall5.isStatic=true;
    wall5.mass = 40.0;
    wall5.material = "hard";
    wall5.canDisappear = true;

    Collider wall6;
    wall6.shape=1;
    wall6.x=210.0;
    wall6.y=310.0;
    wall6.radius=10.0;
    wall6.radius2=60.0;
    wall6.isStatic=true;
    wall6.mass = 40.0;
    wall6.material = "hard";
    wall6.canDisappear = true;

    Collider wall7;
    wall7.shape=1;
    wall7.x=10.0;
    wall7.y=480.0;
    wall7.radius=10.0;
    wall7.radius2=60.0;
    wall7.isStatic=true;
    wall7.mass = 40.0;
    wall7.material = "hard";
    wall7.canDisappear = true;

    Collider wall8;
    wall8.shape=1;
    wall8.x=650.0;
    wall8.y=370.0;
    wall8.radius=10.0;
    wall8.radius2=60.0;
    wall8.isStatic=true;
    wall8.mass = 40.0;
    wall8.material = "hard";
    wall8.canDisappear = true;


    CircleShape player1;
    player1.setPosition(_ball.x, _ball.y);
    player1.setRadius(_ball.radius); 
    player1.setFillColor(Color::White);

    CircleShape red;
    red.setPosition(_ball2.x, _ball2.y);
    red.setRadius(_ball2.radius); 
    red.setFillColor(Color::Red);

    CircleShape yellow;
    yellow.setPosition(_ball3.x, _ball3.y);
    yellow.setRadius(_ball3.radius); 
    yellow.setFillColor(Color::Yellow);


    RectangleShape goal_2;
    goal_2.setPosition(goal2.x, goal2.y);
    goal_2.setSize(Vector2f(goal2.radius,goal2.radius2)); 
    goal_2.setFillColor(orange);

    RectangleShape platform_1;
    platform_1.setPosition(platform.x, platform.y);
    platform_1.setSize(Vector2f(platform.radius,platform.radius2)); 
    platform_1.setFillColor(Color::Green);

    RectangleShape platform_2;
    platform_2.setPosition(platform2.x, platform2.y);
    platform_2.setSize(Vector2f(platform2.radius,platform2.radius2)); 
    platform_2.setFillColor(Color::Blue);

    RectangleShape platform_3;
    platform_3.setPosition(platform3.x, platform3.y);
    platform_3.setSize(Vector2f(platform3.radius,platform3.radius2)); 
    platform_3.setFillColor(Color::Blue);

    RectangleShape platform_4;
    platform_4.setPosition(platform4.x, platform4.y);
    platform_4.setSize(Vector2f(platform4.radius,platform4.radius2)); 
    platform_4.setFillColor(Color::Blue);

    RectangleShape wall_1;
    wall_1.setPosition(wall.x, wall.y);
    wall_1.setSize(Vector2f(wall.radius,wall.radius2)); 
    wall_1.setFillColor(Color::Blue);

    RectangleShape wall_2;
    wall_2.setPosition(wall2.x, wall2.y);
    wall_2.setSize(Vector2f(wall2.radius,wall2.radius2)); 
    wall_2.setFillColor(Color::Blue);

    RectangleShape wall_3;
    wall_3.setPosition(wall3.x, wall3.y);
    wall_3.setSize(Vector2f(wall3.radius,wall3.radius2)); 
    wall_3.setFillColor(Color::Blue);

    RectangleShape wall_4;
    wall_4.setPosition(wall4.x, wall4.y);
    wall_4.setSize(Vector2f(wall4.radius,wall4.radius2)); 
    wall_4.setFillColor(Color::Blue);

    RectangleShape wall_5;
    wall_5.setPosition(wall5.x, wall5.y);
    wall_5.setSize(Vector2f(wall5.radius,wall5.radius2)); 
    wall_5.setFillColor(Color::Blue);

    RectangleShape wall_6;
    wall_6.setPosition(wall6.x, wall6.y);
    wall_6.setSize(Vector2f(wall6.radius,wall6.radius2)); 
    wall_6.setFillColor(Color::Blue);

    RectangleShape wall_7;
    wall_7.setPosition(wall7.x, wall7.y);
    wall_7.setSize(Vector2f(wall7.radius,wall7.radius2)); 
    wall_7.setFillColor(Color::Blue);

    RectangleShape wall_8;
    wall_8.setPosition(wall8.x, wall8.y);
    wall_8.setSize(Vector2f(wall8.radius,wall8.radius2)); 
    wall_8.setFillColor(Color::Blue);


    RectangleShape level1;
    level1.setPosition(200, 500);
    level1.setSize(Vector2f(100,80)); 
    level1.setFillColor(Color::Blue);

    RectangleShape level2;
    level2.setPosition(500, 500);
    level2.setSize(Vector2f(100,80)); 
    level2.setFillColor(Color::Yellow);

    RectangleShape homebutton;
    homebutton.setPosition(350, 700);
    homebutton.setSize(Vector2f(100,80)); 
    homebutton.setFillColor(Color::Green);

    RectangleShape restartButton;
    restartButton.setPosition(20, 750);
    restartButton.setSize(Vector2f(50,40)); 
    restartButton.setFillColor(Color::Green);

    RectangleShape rects[] = {ground_1, goal_1, ledge_1, ledge_2, box_1, side_1, side_2, side_3, side_4, ledge_3, ledge_4, ledge_5, ledge_6};
    int rectsize = 13;

    Collider* colliders[] = {&ball, &ball2, &goal, &box, &side, &side2, &side3,&side4, &ledge, &ledge2, &ledge3, &ledge4, &ledge5, &ledge6, &ground};
    int size=15;


    RectangleShape rects2[] = {ground_1, goal_2, platform_1, platform_2, platform_3, wall_1, wall_2, wall_3, wall_4, wall_5, wall_6, wall_7, wall_8};
    int rectsize2 = 13;

    Collider* colliders2[] = {&_ball, &_ball2, &_ball3, &ground, &goal2, &platform, &platform3,&platform2, &wall, &wall2, &wall3, &wall4, &wall5, &wall6, &wall7, &wall8};
    int size2 = 16;

    while (window.isOpen())
    {
        Event event;
        while (window.pollEvent(event))
        {
            if (event.type == Event::Closed)
                window.close();
        }
        if(scene==0){
            Vector2i mouse_pos = Mouse::getPosition(window);
            if (Mouse::isButtonPressed(Mouse::Left)){
                if (mouse_pos.x >= level1.getPosition().x && mouse_pos.x <= (level1.getPosition().x+level1.getSize().x)
                        && mouse_pos.y>=level1.getPosition().y && mouse_pos.y <= level1.getPosition().y+level1.getSize().y){
                    scene = 1; 
                    main();
                }
                else if (mouse_pos.x >= level2.getPosition().x && mouse_pos.x <= (level2.getPosition().x+level2.getSize().x)
                        && mouse_pos.y>=level2.getPosition().y && mouse_pos.y <= level2.getPosition().y+level2.getSize().y){
                    scene = 2;
                    main();
                }
            }
            window.clear();
            window.draw(title);
            window.draw(instruct);  
            window.draw(instruct2); 
            window.draw(level1);
            window.draw(level2); 
            window.draw(level1_text); 
            window.draw(level2_text);
        }  
        if(scene==1){
            float DT=clock.getElapsedTime().asSeconds();
            if (collision(&ball, &ground)){
                usleep(500000);
                scene = 4;
            }
            if (collision(&ball, &goal)){
                usleep(500000);
                scene = 5;
            }
            do_collisions(colliders, size);
            velocityUpdate(&ball, DT);
            velocityUpdate(&ball2, DT);
            Vector2i mouse_pos = Mouse::getPosition(window);
            if (Mouse::isButtonPressed(Mouse::Left)){
                for (int i=0; i<size; i++){
                    if (mouse_pos.x >= colliders[i]->x && mouse_pos.x <= ((colliders[i]->x)+(colliders[i]->radius))
                        && mouse_pos.y>=colliders[i]->y && mouse_pos.y <= ((colliders[i]->y)+(colliders[i]->radius2)) && colliders[i]->canDisappear == true){
                        size-=1;
                        Collider* disappear = colliders[i];
                        for (int j=i; j<size; j++){
                            colliders[j]= colliders[j+1];
                        }
                        if (disappear->shape == 1){
                            for (int k=0; k<rectsize; k++){
                                if (rects[k].getPosition().x == disappear->x && rects[k].getPosition().y == disappear->y){
                                    rectsize-=1;
                                    for (int l=k; l<rectsize; l++){
                                        rects[l] = rects[l+1];   
                                    }
                                }
                            }
                        }
                    break;
                    }
                }
               
                if (mouse_pos.x >= restartButton.getPosition().x && mouse_pos.x <= (restartButton.getPosition().x+restartButton.getSize().x)
                        && mouse_pos.y>=restartButton.getPosition().y && mouse_pos.x <= restartButton.getPosition().y+restartButton.getSize().y){
                    main();
                }
            }  
            clock.restart();
            player.setPosition(ball.x, ball.y);
            redBall.setPosition(ball2.x, ball2.y);
            window.clear();
            for (int i=0; i<rectsize; i++){
                window.draw(rects[i]);
            }
            window.draw(player);
            window.draw(redBall);
            window.draw(restartButton);
            window.draw(restart);
        }
        if (scene == 2){
            float DT=clock.getElapsedTime().asSeconds();
            if (collision(&_ball, &ground)){
                usleep(500000);
                scene = 4;
            }
            if (collision(&_ball, &goal2)){
                usleep(500000);
                scene = 5;
            }
            do_collisions(colliders2, size2);
            velocityUpdate(&_ball, DT);
            velocityUpdate(&_ball2, DT);
            velocityUpdate(&_ball3, DT);
            Vector2i mouse_pos = Mouse::getPosition(window);

            if (Mouse::isButtonPressed(Mouse::Left)){
                for (int i=0; i<size2; i++){
                    if (mouse_pos.x >= colliders2[i]->x && mouse_pos.x <= ((colliders2[i]->x)+(colliders2[i]->radius))
                        && mouse_pos.y>=colliders2[i]->y && mouse_pos.y <= ((colliders2[i]->y)+(colliders2[i]->radius2)) && colliders2[i]->canDisappear == true){
                        size2-=1;
                        Collider* disappear = colliders2[i];
                        for (int j=i; j<size2; j++){
                            colliders2[j]= colliders2[j+1];
                        }
                        if (disappear->shape == 1){
                            for (int k=0; k<rectsize2; k++){
                                if (rects2[k].getPosition().x == disappear->x && rects2[k].getPosition().y == disappear->y){
                                    rectsize2-=1;
                                    for (int l=k; l<rectsize2; l++){
                                        rects2[l] = rects2[l+1];   
                                    }
                                }
                            }
                        }
                    break;
                    }
                }
                if (mouse_pos.x >= restartButton.getPosition().x && mouse_pos.x <= (restartButton.getPosition().x+restartButton.getSize().x)
                        && mouse_pos.y>=restartButton.getPosition().y && mouse_pos.x <= restartButton.getPosition().y+restartButton.getSize().y){
                    main();
                }
            }  
            clock.restart();
            player1.setPosition(_ball.x, _ball.y);
            red.setPosition(_ball2.x, _ball2.y);
            yellow.setPosition(_ball3.x, _ball3.y);
            window.clear();
            for (int i=0; i<rectsize2; i++){
                window.draw(rects2[i]);
            }
            window.draw(player1);
            window.draw(red);
            window.draw(yellow);
            window.draw(restartButton);
            window.draw(restart);
        }
        if(scene==4){
            Vector2i mouse_pos = Mouse::getPosition(window);
            if (Mouse::isButtonPressed(Mouse::Left)){
                if (mouse_pos.x >= homebutton.getPosition().x && mouse_pos.x <= (homebutton.getPosition().x+homebutton.getSize().x)
                        && mouse_pos.y>=homebutton.getPosition().y && mouse_pos.x <= homebutton.getPosition().y+homebutton.getSize().y){
                    scene = 0;
                }
            }
            window.clear();
            window.draw(fail);
            window.draw(homebutton);
            window.draw(home);  
        }  
        if(scene==5){
            Vector2i mouse_pos = Mouse::getPosition(window);
            if (Mouse::isButtonPressed(Mouse::Left)){
               if (mouse_pos.x >= homebutton.getPosition().x && mouse_pos.x <= (homebutton.getPosition().x+homebutton.getSize().x)
                        && mouse_pos.y>=homebutton.getPosition().y && mouse_pos.x <= homebutton.getPosition().y+homebutton.getSize().y){
                    scene = 0;
                }
            }
            window.clear();
            window.draw(won);
            window.draw(homebutton);
            window.draw(home);   
        }
	    window.display();   
    }

    return 0;
}
           

